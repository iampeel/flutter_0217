//
//  ListNavDemoApp.swift
//  ListNavDemo
//
//  Created by Jungman Bae on 1/14/25.
//

import SwiftUI

@main
struct ListNavDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
